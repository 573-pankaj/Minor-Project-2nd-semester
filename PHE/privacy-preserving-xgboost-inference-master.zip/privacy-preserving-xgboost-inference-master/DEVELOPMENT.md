This code is tested under MacOS (>= Mac OS 10.14), and Ubuntu 18.04
Python version: Python 3.7.3
