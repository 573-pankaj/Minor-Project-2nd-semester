=======
History
=======

0.1.0 (2017-01-01)
------------------

* Use 'cryptography' instead of 'pycrypto'
