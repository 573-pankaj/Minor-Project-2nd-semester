# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0

# Implement your code here.
__author__ = 'Xianrui Meng'
__version__ = '0.0.1'
